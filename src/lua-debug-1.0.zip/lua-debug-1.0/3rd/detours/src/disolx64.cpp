#define DETOURS_X64_OFFLINE_LIBRARY
#include "disasm.cpp"
