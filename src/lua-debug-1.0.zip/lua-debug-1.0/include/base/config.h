#pragma once

#define _BASE_API
