#pragma once

#include <vector>
#include <map>
#include <debugger/protocol.h>
#include <debugger/impl.h>
#include <debugger/lua.h>

namespace vscode {
	class debugger_impl;

	struct value {
		enum class Type {
			local,
			vararg,
			upvalue,
			global,
			standard,
			watch,

			table_int, // todo
			table_str, // todo
			table_idx,
			metatable,
			uservalue,
			func_upvalue,
			debugger_extand,

			userdef,
		};
		size_t     self;
		size_t     parent;
		Type       type;
		int        index;
	};

	struct set_value {
		std::string name;
		std::string value;
		std::string type;
	};

	struct frame {
		std::vector<value> values;
		int frameId;
		int threadId;
		int64_t new_variable(size_t parent, value::Type type, int index);

		frame(int threadId, int frameId);
		void new_scope(debug& debug, lua::Debug* ar, wprotocol& res);
		void clear();
		bool push_value(debug& debug, size_t value_idx);
		bool push_value(debug& debug, const value& v);

		void extand_local(lua_State* L, lua::Debug* ar, debugger_impl& dbg, value const& v, wprotocol& res);
		void extand_global(lua_State* L, lua::Debug* ar, debugger_impl& dbg, value const& v, wprotocol& res);
		void extand_table(lua_State* L, debugger_impl& dbg, value const& v, wprotocol& res);
		void extand_metatable(lua_State* L, debugger_impl& dbg, value const& v, wprotocol& res);
		void extand_userdata(lua_State* L, lua::Debug* ar, debugger_impl& dbg, value const& v, wprotocol& res);
		void extand_function(lua_State* L, lua::Debug* ar, debugger_impl& dbg, value const& v, wprotocol& res);
		void extand_userdef(debug& debug, debugger_impl& dbg, value const& v, wprotocol& res);
		void get_variable(debug& debug, lua::Debug* ar, debugger_impl& dbg, int64_t valueId, wprotocol& res);

		bool set_table(lua_State* L, lua::Debug* ar, debugger_impl& dbg, set_value& setvalue);
		bool set_userdata(lua_State* L, lua::Debug* ar, debugger_impl& dbg, set_value& setvalue);
		bool set_local(lua_State* L, lua::Debug* ar, set_value& setvalue);
		bool set_vararg(lua_State* L, lua::Debug* ar, set_value& setvalue);
		bool set_upvalue(lua_State* L, lua::Debug* ar, set_value& setvalue);
		bool set_global(lua_State* L, lua::Debug* ar, debugger_impl& dbg, set_value& setvalue);
		bool set_variable(debug& debug, lua::Debug* ar, debugger_impl& dbg, set_value& setvalue, int64_t valueId);
	};

	struct observer {
		std::map<int, frame> frames;
		int                  threadId;

		observer(int threadId);
		void    reset(lua_State* L = nullptr);
		frame*  create_or_get_frame(int frameId);
		int64_t new_watch(lua_State* L, int idx, frame* frame, const std::string& expression);
		void    evaluate(lua_State* L, lua::Debug *ar, debugger_impl& dbg, rprotocol& req, int frameId);
		void    new_frame(debug& debug, debugger_impl& dbg, rprotocol& req, int frameId);
		void    get_variable(debug& debug, debugger_impl& dbg, rprotocol& req, int64_t valueId, int frameId);
		void    set_variable(debug& debug, debugger_impl& dbg, rprotocol& req, int64_t valueId, int frameId);
	};
}
