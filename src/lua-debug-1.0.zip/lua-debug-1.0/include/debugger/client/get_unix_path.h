#pragma once

#include <string>

std::string get_unix_path(int pid);
