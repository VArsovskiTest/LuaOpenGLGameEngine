#pragma once

#include <Windows.h>

namespace delayload {
	void set_luadll(HMODULE handle);
}
